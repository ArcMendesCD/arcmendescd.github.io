<?php
	$inicio = microtime();
	$i = 1;
	
	while($i <= 10000){
		echo "Escrevendo linha $i<br>";
		$i++;
	}
	$final = microtime();
	$tempo = $final - $inicio;
	echo "Pagina gerada em $tempo"
?>