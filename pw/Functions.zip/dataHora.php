<?php
	date_default_timezone_set("America/New_York");
	$data = date("d/m/y");
	$hora = date("H:i:s");
	
	echo "Data Atual: ", $data;
	echo "<br>Hora Atual: ", $hora;
?>