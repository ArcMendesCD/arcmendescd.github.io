<?php

//FUNCTION SUM
	function sum($n1, $n2){
		$totalSum = $n1 + $n2;
		return $totalSum;
	}
	
//FUNCTION SUBTRACTION
	function subtraction($n1, $n2){
		$totalSub = $n1 - $n2;
		return $totalSub;
	}

//FUNCTION MULTIPLICATION
	function multiplication($n1, $n2){
		$totalMulti = $n1 * $n2;
		return $totalMulti;
	}

//FUNCTION DIVISION	
	function division($n1, $n2){
		$totalDiv = $n1 / $n2;
		return $totalDiv;
	}
	
//FUNCTION FATORIAL
	function fatorial($fat){
	$result = 1;
    echo "Fatorial de " . $fat . " = ";
    while($fat > 1){ 
    $result *= $fat;
    $fat--;
    }                
    return $result;                    
  } 
	
?>