<?php

require "functions.php";

$brdate ="30-05-2021";

echo "Data PT-BR: ",$brdate;

$nDate = date("Y-m-d",strtotime($brdate));

echo "<br><br>Nova data: ",$nDate;

?>