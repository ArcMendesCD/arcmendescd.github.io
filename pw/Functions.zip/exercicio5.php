<?php

require "functions.php";

$usdate ="2021-05-30";

echo "Data US: ",$usdate;

$nDate = date("d-m-Y",strtotime($usdate));

echo "<br><br>Nova data: ",$nDate;

?>