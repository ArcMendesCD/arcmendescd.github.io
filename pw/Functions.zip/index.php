<h1>INDEX</h1>
<br>
<br>
<a href="exercicio1-2.php">Exercicios 1 e 2</a>
<a href="exercicio3.php">Exercicio 3</a>
<a href="exercicio4.php">Exercicio 4</a>
<a href="exercicio5.php">Exercicio 5</a>
<a href="exercicio6.php">Exercicio 6</a>
<br>
<br>
<p>Não fiz o exercicio 7 pois as funções dos exercicios 4 5 6 são exibidas na mesma página.</p>