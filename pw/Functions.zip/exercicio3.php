<?php

require "functions.php";

$nome ="Arthur Wellesley<br><br>";

echo "Nome: ",$nome;

$m = strtoupper($nome);

echo "Nome em Maiusculo: ",$m;

?>