<?php

require "functions.php";

$v1 = 20;
$v2 = 10;

$respSum = sum($v1, $v2);
$respSub = subtraction($v1, $v2);
$respMulti = multiplication($v1, $v2);
$respDiv = Division($v1, $v2);

echo "Soma: ",$respSum;
echo "<br>Subtração: ",$respSub;
echo "<br>Multiplicação: ",$respMulti;
echo "<br>Divisão: ",$respDiv;

?>