<?php

	require "functions.php";
	
    $x = fatorial(10);
    echo $x;

?>