<html>
<body>
<h1 style="text-align: center;">Pagina Principal</h1>
<br>
<a href="E1.php">Exercício 1</a>
<br>
<a href="E2.php">Exercício 2</a>
<br>
<a href="E3.php">Exercício 3</a>
<br>
<hr>
<br>
<a href="index.php">Voltar para a página principal</a>
<br>
<a href="index.php">Retornar para a página anterior</a>
</body>
</html>
