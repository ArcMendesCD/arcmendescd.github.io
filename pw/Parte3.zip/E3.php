<html>
<body>
<h1 style="text-align: center;">?</h1>
<p> não entendi o exercício 3</p>
<br><br>
<a href="index.php">Voltar para a página principal</a>
<br>
<a href="index.php">Retornar para a página anterior</a>
</body>
</html>
