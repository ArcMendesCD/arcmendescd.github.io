<html>
<body>
<h1 style="text-align: center;">Contador Decrescente</h1>
<?php
$i = "0";

for($i=100; $i>=50; $i--) {
	echo $i.", ";
    
}
?>
<br><br>
<a href="index.php">Voltar para a página principal</a>
<br>
<a href="index.php">Retornar para a página anterior</a>
</body>
</html>
