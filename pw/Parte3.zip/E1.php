<html>
<body>
<h1 style="text-align: center;">Contador</h1>
<?php
$i = "0";

for($i=10; $i<=100; $i++) {
	echo $i.", ";
    
}
?>
<br><br>
<a href="index.php">Voltar para a página principal</a>
<br>
<a href="index.php">Retornar para a página anterior</a>
</body>
</html>
