<html>
<head>
<meta charset="UTF-8">
</head
<body>
<h1>Insira o valor</h1>
<hr>
<form action="./Atividade5Resultado.php" method="get">
Salário base: <input type="text" name="v1"/><br>
Vendas: <input type="text" name="v2"/><br>
<input type="submit" value="Calcular"/>
</form>
<a href="Index.php">Voltar ao Início</a>
</body>
</html>