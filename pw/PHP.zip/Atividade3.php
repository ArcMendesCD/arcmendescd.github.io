<h1>Atividade 1</h1>
<br><br>

<?php
$i = "0";
$num = "101";

while($i<10) {
	if($num>100){
		$i++;
		echo $num.", ";
	}
	$num++;
}
?>