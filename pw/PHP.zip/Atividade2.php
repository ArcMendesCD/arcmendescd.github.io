<h1>Atividade 1</h1>
<br><br>

<?php
$i = "100";

while($i>=50) {
	echo $i.", ";
	$i--;
}
?>