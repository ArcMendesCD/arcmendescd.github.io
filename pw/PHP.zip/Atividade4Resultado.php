<meta charset="UTF-8">
<h1 style="text-align:center;">Resultado:</h1>
<hr>
<?php
$horas = $_GET["v1"];
$salario = $_GET["v2"];
$horasextra = $horas - 40;
$salariobase = (($horas-$horasextra)*$salario);
$salariocompleto = "0";
echo "Horas Trabalhadas " . $horas . "<br>Salário por hora:" . $salario . "<br>Salário base: ".$salariobase."<br><hr>";
$salariodobro = $salario+($salario/2);

if ($horas > 40) {
	$acrescimo = $horasextra*$salariodobro;
	$salariocompleto = $salariobase + $acrescimo;
	echo "Salário do funcionario é: ".$salariocompleto."<br><br>";
}
if ($horas <= 40) {
	echo "Salário do funcionario é:".$salariobase."<br><br>";
}
?>
<a href="Atividade4.php">Voltar a pagina anterior</a>
<a href="Index.php">Voltar ao Início</a>

