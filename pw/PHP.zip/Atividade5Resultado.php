<meta charset="UTF-8">
<h1 style="text-align:center;">Resultado:</h1>
<hr>
<?php
$salario = $_GET["v1"];
$vendas = $_GET["v2"];
$comissão = "0";

echo "Salário base: ".$salario."<br><hr><br>";

if($vendas < 1500) {
	$comissao = (($vendas/100)*3);
	$salario = ($salario+$comissao);
	echo "O salário do funcionario é: ".$salario;
}
elseif ($vendas >= 1500) {
	$comissao = (($vendas/100)*5);
	$salario = ($salario+$comissao);
	echo "O salário do funcionario é: ".$salario."<br><br>";
}
?>
<a href="Atividade5.php">Voltar a pagina anterior</a>
<a href="Index.php">Voltar ao Início</a>

