<h1>Atividade 1</h1>
<br><br>

<?php
$i = "10";

while($i<=100) {
	echo $i.", ";
	$i++;
}
?>