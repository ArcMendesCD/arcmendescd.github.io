//made by Andrei R.C Mendes, website link, https://arcmendescd.github.io/index.html
package Auto;
import java.util.Scanner;

public class TesteCarro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner input = new Scanner(System.in);
        
        int opt = 0;
		Carro carro1 = new Carro();
		Carro carro2 = new Carro();
		//main body CAR 1
		System.out.println("CARRO 1: ");
		
		
		System.out.println("Digite o modelo do carro: ");
		carro1.setModelo(input.nextLine());
		
		System.out.printf("Digite a marca do carro: ");
		carro1.setMarca(input.nextLine());
		
		System.out.printf("Digite o ano do carro: ");
		carro1.setAno(input.nextLine());
		
		System.out.printf("Digite a cor do carro: ");
		carro1.setCor(input.nextLine());
		
		System.out.printf("Digite o pre�o do carro: ");
		carro1.setPreco(input.nextLine());

		//main body CAR 2
		System.out.println("CARRO 2: ");

		
		System.out.println("Digite o modelo do carro: ");
		carro2.setModelo(input.nextLine());
		
		System.out.printf("Digite a marca do carro: ");
		carro2.setMarca(input.nextLine());
		
		System.out.printf("Digite o ano do carro: ");
		carro2.setAno(input.nextLine());
		
		System.out.printf("Digite a cor do carro: ");
		carro2.setCor(input.nextLine());
		
		System.out.printf("Digite o pre�o do carro: ");
		carro2.setPreco(input.nextLine());
		
		
		//printing of the main results
		System.out.println("CARRO 1: \n");
		System.out.println(carro1.getModelo());
		System.out.println(carro1.getMarca());
		System.out.println(carro1.getAno());
		System.out.println(carro1.getCor());
		System.out.println(carro1.getPreco());
		
		System.out.println("\n\nCARRO 2: \n");
		System.out.println(carro2.getModelo());
		System.out.println(carro2.getMarca());
		System.out.println(carro2.getAno());
		System.out.println(carro2.getCor());
		System.out.println(carro2.getPreco());

		while (opt!=5) {
			System.out.println("\n\nMenu Principal");
			System.out.println("[1] - Alterar Carro 1");
			System.out.println("[2] - Alterar Carro 2");
			System.out.println("[3] - Mostrar Carro 1");
			System.out.println("[4] - Mostrar Carro 2");
			System.out.println("[5] - Finalizar Programa");
			
			opt = input.nextInt();
			if (opt != 5) {
				if (opt == 1) {
					System.out.println("Digite o modelo do carro: ");
					carro1.setModelo(input.nextLine());
					System.out.printf("Digite a marca do carro: ");
					carro1.setMarca(input.nextLine());
					System.out.printf("Digite o ano do carro: ");
					carro1.setAno(input.nextLine());
					System.out.printf("Digite a cor do carro: ");
					carro1.setCor(input.nextLine());
					System.out.printf("Digite o pre�o do carro: ");
					carro1.setPreco(input.nextLine());
				}
				else if (opt == 2) {
						System.out.println("Digite o modelo do carro: ");
						carro2.setModelo(input.nextLine());
						System.out.printf("Digite a marca do carro: ");
						carro2.setMarca(input.nextLine());
						System.out.printf("Digite o ano do carro: ");
						carro2.setAno(input.nextLine());
						System.out.printf("Digite a cor do carro: ");
						carro2.setCor(input.nextLine());
						System.out.printf("Digite o pre�o do carro: ");
						carro2.setPreco(input.nextLine());
				}
				else if (opt == 3) {
					System.out.println("CARRO 1: \n");
					System.out.println(carro1.getModelo());
					System.out.println(carro1.getMarca());
					System.out.println(carro1.getAno());
					System.out.println(carro1.getCor());
					System.out.println(carro1.getPreco());
				}
				else if (opt == 4) {
					System.out.println("CARRO 2: \n");
					System.out.println(carro2.getModelo());
					System.out.println(carro2.getMarca());
					System.out.println(carro2.getAno());
					System.out.println(carro2.getCor());
					System.out.println(carro2.getPreco());
			    }
				else {
					System.out.println("FINALIZANDO O PROGRAMA.");
				}
			}
		
}
	
}
}