package Auto;

//all values are Strings because I was getting an error when executing the main which was "the Method "ano/preco" is not applicable for the arguments(String)"
public class Carro {
private String marca;
private String modelo;
private String ano;
private String cor;
private String preco;


//Atributo "marca" GET SET
public String getMarca() {
return this.marca;
}

public void setMarca(String marca) {
	this.marca = marca;
}

//Atributo "modelo" GET SET
public String getModelo() {
	return this.modelo;
}

public void setModelo(String modelo) {
	this.modelo = modelo;
}

//Atributo "ano" GET SET
public String getAno() {
	return this.ano;
}

public void setAno(String ano) {
	this.ano = ano;
}

//Atributo "cor" GET SET
public String getCor() {
	return this.cor;
}

public void setCor(String cor) {
	this.cor = cor;
}

//Atributo "preco" GET SET
public String getPreco() {
	return this.preco;
}

public void setPreco(String preco) {
	this.preco = preco;
}

}