//exercicio6.java
import java.util.Scanner;

public class exercicio6{
	public static void main (String args[]){
	    
		Scanner leia = new Scanner(System.in);
		
		System.out.println ("Informe a Idade do atleta: \n");
		int idade = leia.nextInt();
		
        if (idade >= 5 && idade <= 11) { 	
        	System.out.printf ("O atleta é da categoria Infantil.");
        }
        else if (idade >= 12 && idade <= 17)	{
	    	System.out.printf ("O atleta é da categoria Juvenil.");
        }
        else if (idade >= 18) { 
	        System.out.printf ("O atleta é da categoria Adulto.");
        }
        else {
	        System.out.printf ("Pessoa é jovem demais para ser classificada.");
        }
	}
}
		