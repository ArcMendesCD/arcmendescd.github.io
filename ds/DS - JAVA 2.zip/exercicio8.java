//exercicio4.java
import java.util.Scanner;

public class exercicio4{
	public static void main (String args[]){
		Scanner leia = new Scanner(System.in);
		
		float max = 0;
		
		System.out.println ("Informe o primeiro número: \n");
		float num1 = leia.nextFloat();
		System.out.println ("Informe o segundo número: \n");
		float num2 = leia.nextFloat();
		System.out.println ("Informe o terceiro número: \n");
		float num3 = leia.nextFloat();
		
        if (num1 > num2 && num1 > num3) { 	
        	max = num1;
        }
        else if (num2 > num3)	{
	        max = num2;
        }
        else { 
	        max = num3;	
        }
        
		System.out.printf ("O maior número é: "+max);
	}
}
		