//exercicio1.java
import java.util.Scanner;

public class exercicio1{
	public static void main (String args[]){
		Scanner leia = new Scanner(System.in);		
		System.out.println ("Informe um número(Inteiro): ");
		int num = leia.nextInt();
        if (num > 100){
            num = num + 150;
            System.out.printf ("O número inserido é maior que 100 portanto foi somado 150 ao seu valor.\n\n ");
        }
        
        else {
            System.out.printf ("Número menor que 100 portanto, nada foi somado ao valor.\n\n");
        }
		System.out.printf ("O número é: "+num);
	}
}
		