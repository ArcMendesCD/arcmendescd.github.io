//exercicio2.java
import java.util.Scanner;

public class exercicio2{
	public static void main (String args[]){
		Scanner leia = new Scanner(System.in);		
		System.out.println ("Informe um número(Inteiro): \n");
		int num = leia.nextInt();
        if (num > 5 && num < 20){
            num = num * num;
            System.out.printf ("O número inserido é maior que 5 e menor que 20 portanto seu cubo será exibido.\n\n ");
        }
        
        else {
            System.out.printf ("Número não atende os requisitos(num > 5 && num < 20).\n\n");
        }
		System.out.printf ("O número é: "+num);
	}
}
		