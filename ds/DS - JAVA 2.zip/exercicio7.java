//exercicio3.java
import java.util.Scanner;

public class exercicio3{
	public static void main (String args[]){
		Scanner leia = new Scanner(System.in);
		System.out.println ("Informe o primeiro número(Inteiro e maior que 0): \n");
		int num1 = leia.nextInt();
		int dif = 0;
		System.out.println ("Informe o segundo número(Inteiro e maior que 0): \n");
		int num2 = leia.nextInt();
        if (num1 > 0 && num2 > 0){
            if(num1 > num2){
            dif = (num1 - num2);
            System.out.printf ("O primeiro número é maior que o segundo portanto Diferença = num1 - num2.\n\n");
            }
            else if(num1 < num2){
            dif = (num2 - num1);
            System.out.printf ("O segundo número é maior que o primeiro portanto Diferença = num2 - num1.\n\n");
            }
            else {
            System.out.printf ("Os dois números são iguais.\n\n");
            }
        }
        else {
            System.out.printf ("Um dos números ou ambos não são maiores que 0.\n\n");
        }
		System.out.printf ("A diferença é: "+dif);
	}
}
		