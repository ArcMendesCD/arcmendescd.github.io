//exercicio5.java
import java.util.Scanner;

public class exercicio5{
	public static void main (String args[]){
	    
	    String name;
	    
		Scanner leia = new Scanner(System.in);
		
		System.out.println ("Informe o nome do aluno: \n");
        name = leia.next();
		System.out.println ("Informe a media do aluno: \n");
		float media = leia.nextFloat();
		if (media >= 6.0){
		    System.out.printf (name+" foi aprovado, nota: "+media);
		}
		else {
		   	System.out.printf (name+" foi reprovado, nota: "+media);
		}
	}
}
		